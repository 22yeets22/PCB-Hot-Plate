G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.5*
G04 #@! TF.CreationDate,2026-04-19T17:37:07-05:00*
G04 #@! TF.ProjectId,Hot-Plate-Board,486f742d-506c-4617-9465-2d426f617264,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.5) date 2026-04-19 17:37:07*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250000X0.250000X0.250000X-0.250000X0.250000X-0.250000X-0.250000X0.250000X-0.250000X0*%
%ADD11C,3.200000*%
%ADD12R,1.700000X1.700000*%
%ADD13C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,*
X136228725Y-116847892D03*
X48628725Y-116847892D03*
G04 #@! TD*
D11*
G04 #@! TO.C,REF\u002A\u002A*
X45844205Y-122370923D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X45806038Y-29081883D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J1*
X88665246Y-123106946D03*
D13*
X91205246Y-123106946D03*
X93745246Y-123106946D03*
X96285246Y-123106946D03*
G04 #@! TD*
D11*
G04 #@! TO.C,REF\u002A\u002A*
X139164239Y-122403853D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X139225432Y-29081883D03*
G04 #@! TD*
M02*
